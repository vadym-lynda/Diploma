package ua.te.gourmetguru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GourmetGuruApplicationTests {

	@Test
	void contextLoads() {
	}

}
