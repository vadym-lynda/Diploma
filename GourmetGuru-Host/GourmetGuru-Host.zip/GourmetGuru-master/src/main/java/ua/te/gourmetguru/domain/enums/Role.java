package ua.te.gourmetguru.domain.enums;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
