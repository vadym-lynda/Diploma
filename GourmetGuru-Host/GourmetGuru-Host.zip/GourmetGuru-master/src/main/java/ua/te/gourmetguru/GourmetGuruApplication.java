package ua.te.gourmetguru;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GourmetGuruApplication {

	public static void main(String[] args) {
		SpringApplication.run(GourmetGuruApplication.class, args);
	}

}
