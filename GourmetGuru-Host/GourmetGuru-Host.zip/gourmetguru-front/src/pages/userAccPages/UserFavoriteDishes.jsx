

function UserAccountFavoriteDishes() {
  console.log('Page UserAccountFavoriteDishes')
  return(null
  //   <RecipeList  route='http://localhost:8080/api/favourite-dishes'/>
   )
}

export default UserAccountFavoriteDishes;